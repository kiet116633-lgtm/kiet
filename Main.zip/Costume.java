package Ungdungthuetrangphuc ;

public class Costume {
    String name;
    String type;
    double pricePerday;

    public Costume(String name, String type, double pricePerday){
        this.name = name;
        this.type = type;
        this.pricePerday = pricePerday;
    }

    public double getPricePerDay() {
        return pricePerday;
    }

    public void showInfo() {
        System.out.println(
            "Ten: " + name + 
            "  Loai: " + type + 
            "  Gia/ngay: " + pricePerday);
    }
}