package Ungdungthuetrangphuc;

import java.util.ArrayList;

public class CostumeRental {
    private Customer customer;
    private ArrayList<Costume> costumes;
    private int days;

    public CostumeRental(Customer customer, int days) {
        this.customer = customer;
        this.days = days;
        this.costumes = new ArrayList<>();
    }

    public void addCostume(Costume c) {
        costumes.add(c);
    }

    public double totalPrice() {
        double total = 0;

        for (Costume c : costumes) {
            total += c.getPricePerDay() * days;
        }

        if (days > 2) {
            total *= 0.85; 
        }

        total += costumes.size() * 30000;

        return total;
    }

    public void showBill() {
        System.out.println("===== HOA DON THUE TRANG PHUC =====");
        customer.showInfo();
        System.out.println("So ngay thue: " + days);

        System.out.println("Danh sach trang phuc:");
        for (Costume c : costumes) {
            c.showInfo();
        }

        System.out.println("Tong tien: " + totalPrice());
    }
}

