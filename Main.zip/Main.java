package Ungdungthuetrangphuc;

public class Main {
    public static void main(String[] args) {
        Costume c1 = new Costume("Ao dai", "Truyen thong", 100000);
        Costume c2 = new Costume("Trang phuc cong chua", "Cosplay", 150000);
        Costume c3 = new Costume("Vest", "Lich su", 120000);

        Customer cus1 = new Customer("Linh", "0987654321");

        CostumeRental rental1 = new CostumeRental(cus1, 3); 
        rental1.addCostume(c1);
        rental1.addCostume(c2);
        rental1.addCostume(c3);
        Customer cus2 = new Customer("Hieu", "0912394567");

        CostumeRental rental2 = new CostumeRental(cus2, 5); 
        rental2.addCostume(c1);
        rental2.addCostume(c3);

        rental1.showBill();
        rental2.showBill();
    }
}
