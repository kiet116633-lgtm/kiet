package Ungdungthuetrangphuc;

public class Customer {
     String name;
     String phone;

    public Customer(String name, String phone) {
        this.name = name;
        this.phone = phone;
    }

    public void showInfo() {
        System.out.println(
            "Khach hang: " + name + 
            "  SDT: " + phone);
    }
}

